<?php
$_['advancedsorting_path'] = 'extension/module/advancedsorting';
$_['advancedsorting_model'] = 'model_extension_module_advancedsorting';
$_['advancedsorting_name'] = 'advancedsorting';
$_['advancedsorting_version'] = '1.3.3';