<?php
class ControllerExtensionModuleAdvancedSorting extends Controller {
	private $data = array();
	private $error = array();
	private $version;
	private $module_path;
	private $extensions_link;
	private $language_variables;
	private $moduleModel;
	private $moduleName;
	private $call_model;
	private $isenseWrapper;

	public function __construct($registry){
		parent::__construct($registry);
		$this->load->config('isenselabs/advancedsorting');
		$this->moduleName = $this->config->get('advancedsorting_name');
		$this->call_model = $this->config->get('advancedsorting_model');
		$this->module_path = $this->config->get('advancedsorting_path');
		$this->version = $this->config->get('advancedsorting_version');
		
		if (version_compare(VERSION, '2.3.0.0', '>=')) {			
			$this->extensions_link = $this->url->link('extension/extension', 'token=' . $this->session->data['token'].'&type=module', 'SSL');
		} else {
			$this->extensions_link = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');	
		}
			
		$this->load->model($this->module_path);
		$this->moduleModel = $this->{$this->call_model};
    	$this->language_variables = $this->load->language($this->module_path);

    	//Loading framework models
	 	$this->load->model('setting/store');
		$this->load->model('setting/setting');
        $this->load->model('localisation/language');
        if(VERSION >= '2.1.0.1'){
			$this->load->model('customer/customer_group');
		} else {
			$this->load->model('sale/customer_group');
		}

		$this->document->addScript('view/javascript/summernote/summernote.js');
		$this->document->addStyle('view/javascript/summernote/summernote.css');

		$this->data['module_path']     = $this->module_path;
		$this->data['moduleName']      = $this->moduleName;
		$this->data['moduleNameSmall'] = $this->moduleName;	    
	}

    public function index() {
		foreach ($this->language_variables as $code => $languageVariable) {
		    $this->data[$code] = $languageVariable;
		}  
		// Load models
		$this->load->model('catalog/product');
		
		// Load script & stylesheets
        $this->document->addStyle('view/stylesheet/'.$this->moduleName.'/'.$this->moduleName.'.css');
		$this->document->addScript('view/javascript/'.$this->moduleName.'/main.js');
		
		// Set main title
        $this->document->setTitle($this->language->get('heading_title').' '.$this->version);
        $this->data['heading_title'] =  $this->data['heading_title'].' '.$this->version;
        if(!isset($this->request->get['store_id'])) {
           $this->request->get['store_id'] 	= 0; 
        }
		
		// Get store info
        $store 								= $this->getCurrentStore($this->request->get['store_id']);
		
		// Save module settings
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) { 	
            if (!empty($_POST['OaXRyb1BhY2sgLSBDb21'])) {
                $this->request->post[$this->moduleName]['LicensedOn'] = $_POST['OaXRyb1BhY2sgLSBDb21'];
            }
            if (!empty($_POST['cHRpbWl6YXRpb24ef4fe'])) {
                $this->request->post[$this->moduleName]['License'] = json_decode(base64_decode($_POST['cHRpbWl6YXRpb24ef4fe']), true);
            }

        	$this->model_setting_setting->editSetting($this->moduleName, $this->request->post, $this->request->post['store_id']);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link($this->module_path, 'store_id='.$this->request->post['store_id'] . '&token=' . $this->session->data['token'], 'SSL'));
        }
		
		// Get success message
		if (isset($this->session->data['success'])) {
			$this->data['success'] 				= $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$this->data['success'] 				= '';
		}
		
		// Get error/warning message
		if (isset($this->error['warning'])) {
			$this->data['error_warning'] 			= $this->error['warning'];
		} else {
			$this->data['error_warning'] 			= '';
		}

		// Breadcrumb data
        $this->data['breadcrumbs']   				= array();
        $this->data['breadcrumbs'][] 				= array(
            'text' 					=> $this->language->get('text_home'),
            'href' 					=> $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL'),
        );
        $this->data['breadcrumbs'][] 				= array(
            'text' 					=> $this->language->get('text_module'),
            'href' 					=> $this->extensions_link,
        );
        $this->data['breadcrumbs'][] 				= array(
            'text' 					=> $this->language->get('heading_title'),
            'href' 					=> $this->url->link($this->module_path, 'token=' . $this->session->data['token'], 'SSL'),
        );

		
		// Data for the template files
        $this->data['stores']						= array_merge(array(0 => array('store_id' => '0', 'name' => $this->config->get('config_name') . ' (' . $this->data['text_default'].')', 'url' => HTTP_SERVER, 'ssl' => HTTPS_SERVER)), $this->model_setting_store->getStores());
        $this->data['languages']              	= $this->model_localisation_language->getLanguages();
        $this->data['store']                  	= $store;
        $this->data['token']                  	= $this->session->data['token'];
        $this->data['action']                 	= $this->url->link($this->module_path, 'token=' . $this->session->data['token'], 'SSL');

        $this->data['cancel']                 	= $this->extensions_link;
		$this->data['moduleSettings']				= $this->model_setting_setting->getSetting($this->moduleName, $store['store_id']);
        $this->data['moduleData']					= (isset($this->data['moduleSettings'][$this->moduleName])) ? $this->data['moduleSettings'][$this->moduleName] : array();
		$this->data['language_id']				= $this->config->get('config_language_id');
		$this->data['modelCatalogProduct']		= $this->model_catalog_product;
		$this->data['currency']					= $this->config->get('config_currency');

		// Get the the main OpenCart admin styles & design
		$this->data['header']						= $this->load->controller('common/header');
		$this->data['column_left']				= $this->load->controller('common/column_left');
		$this->data['footer']						= $this->load->controller('common/footer');
		
		// Outputs the data from the function
		$this->response->setOutput($this->load->view($this->module_path.'/advancedsorting.tpl', $this->data));
    }
	
	// Check for permissions 
	protected function validateForm() {
		if (!$this->user->hasPermission('modify', $this->module_path)) {
			$this->error['warning'] 		= $this->language->get('error_permission');
		}
		
		return !$this->error;
	}
	
	// Module-specific settings
	public function get_store_settings() {
		
		$this->data['languages']					= $this->model_localisation_language->getLanguages();
		$this->data['language_id']				= $this->config->get('config_language_id');
		$this->data['storedata']['id']			= $this->request->get['storedata_id'];
		$store_id							= $this->request->get['store_id'];
		$this->data['data']						= $this->model_setting_setting->getSetting($this->moduleName, $store_id);
		$this->data['moduleName']					= $this->moduleName;
		$this->data['moduleData']					= (isset($this->data['data'][$this->moduleName])) ? $this->data['data'][$this->moduleName] : array();
		$this->data['newAddition']				= true;
		
		// Outputs the data from the function
		$this->response->setOutput($this->load->view($this->module_path.'/tab_storetab.tpl', $this->data));
	}
	
	// Module installation
    public function install() {
	    $this->moduleModel->install();
    }
    
	// Module uninstallation
    public function uninstall() {
		
		$this->model_setting_setting->deleteSetting($this->moduleName, 0);
		$stores=$this->model_setting_store->getStores();
		foreach ($stores as $store) {
			$this->model_setting_setting->deleteSetting($this->moduleName, $store['store_id']);
		}
        $this->moduleModel->uninstall();
    }
	
	// Gets the front-end URL
    private function getCatalogURL() {
        if (isset($_SERVER['HTTPS']) && (($_SERVER['HTTPS'] == 'on') || ($_SERVER['HTTPS'] == '1'))) {
            $storeURL 						= HTTPS_CATALOG;
        } else {
            $storeURL 						= HTTP_CATALOG;
        } 
        return $storeURL;
    }

	// Get the data about a given store
    private function getCurrentStore($store_id) {    
        if($store_id && $store_id != 0) {
            $store 							= $this->model_setting_store->getStore($store_id);
        } else {
            $store['store_id'] 				= 0;
            $store['name'] 					= $this->config->get('config_name');
            $store['url']					= $this->getCatalogURL(); 
			$store['ssl']					= $this->getCatalogURL();
        }
		
        return $store;
    }
}
?>