function showHideStuff($typeSelector, $toggleArea, $selectStatus) {
	if ($typeSelector.val() === $selectStatus) {
		$toggleArea.show(); 
	} else {
		$toggleArea.hide(); 
	}
    $typeSelector.change(function(){
        if ($typeSelector.val() === $selectStatus) {
            $toggleArea.show(300); 
        }
        else {
            $toggleArea.hide(300); 
        }
    });
}

$(document).ready(function() {
	$('.sorting').change(function(e) {
		if ($(this).val() == 'p.viewed') {
			$(this).parents('.row').find('.sorted').val('DESC');
			$(this).parents('.row').find('.sorted').hide();
		} else if ($(this).val() == 'p.sort_order') {
			$(this).parents('.row').find('.sorted').val('ASC');
			$(this).parents('.row').find('.sorted').hide();
		} else {
			$(this).parents('.row').find('.sorted').show();
		}
	});
	
	$(".sorting").each(function(i) {
		if ($(this).val() == 'p.viewed') {
			$(this).parents('.row').find('.sorted').val('DESC');
			$(this).parents('.row').find('.sorted').hide();
		} else if ($(this).val() == 'p.sort_order') {
			$(this).parents('.row').find('.sorted').val('ASC');
			$(this).parents('.row').find('.sorted').hide();
		} else {
			$(this).parents('.row').find('.sorted').show();
		}
	});
});