<?php
// Text
$_['text_viewed']      = 'Most Viewed';
$_['text_date_added_asc']      = 'Date added (A - Z)';
$_['text_date_added_desc']      = 'Date added (Z - A)';
$_['text_date_added_rand']      = 'Date added (random)';
$_['text_date_modified_asc']      = 'Date modified (A - Z)';
$_['text_date_modified_desc']      = 'Date modified (Z - A)';               
$_['text_date_modified_rand']      = 'Date modified (random)';
$_['text_model_rand']   = 'Model (random)';
$_['text_rating_rand']   = 'Rating (random)';
$_['text_price_rand']   = 'Price (random)';
$_['text_name_rand']   = 'Name (random)';
$_['text_number_sales_asc'] = 'Number of sales (Low &gt; High)';
$_['text_number_sales_desc'] = 'Number of sales (High &gt; Low)';
$_['text_number_sales_rand'] = 'Number of sales (random)';